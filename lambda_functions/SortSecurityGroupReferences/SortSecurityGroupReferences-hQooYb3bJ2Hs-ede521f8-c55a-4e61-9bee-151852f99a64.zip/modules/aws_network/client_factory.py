import boto3
from botocore.config import Config

#@mock_ec2
class ClientFactory:
    """
    This class is used to build a boto3 session and return the EC2 client 
    for other modules in this package. This will accept credentials from 
    a credential file, credentials set as default, and those obtained 
    from a role session.

    This can be used to return an EC2 client on its own, but is 
    specifically designed to be used with the other modules in this package.

    Attributes
    ----------
    aws_profile: str
        The AWS profile to use - as saved in credential file.
    aws_region: str
        The AWS region to make API calls against, you must
        specify a region if using aws_profile
    role_arn: str
        The arn of the role to assume
    role_session_name: str
        The name to use for the role session
    
    Examples
    -------
    call with default credentials, normally set with aws configure
      cf = ClientFactory()
    call with named profile test against eu-west-2 region  
      cf = ClientFactory(aws_profile='test',aws_region='eu-west-2')
    call with a role and default credentials
      cf = ClientFactory(role_arn='arn:aws:iam::123456789012:role/my_role',role_session_name='my_role_session')
    call with a role and a profile
      cf = ClientFactory(
        aws_profile='test',
        aws_region='eu-west-2',
        role_arn='arn:aws:iam::123456789012:role/my_role',
        role_session_name='my_role_session')
    """

    def __init__(self,aws_profile:str=None,aws_region:str=None,role_arn:str=None,role_session_name:str=None) -> None:
        if aws_profile:
            self.aws_profile = aws_profile
            self.aws_region = aws_region
            self._session = boto3.session.Session(
                profile_name=self.aws_profile,region_name=self.aws_region
            )
        else:
            self._session = boto3.session.Session()
        if role_arn:
            sts_client = self._session.client('sts')
            self.role_arn = role_arn
            self.role_session_name = role_session_name
            sts_credentials = sts_client.assume_role(RoleArn=self.role_arn,RoleSessionName=self.role_session_name)['Credentials']
            if aws_region:
                self._session = boto3.session.Session(
                    aws_access_key_id=sts_credentials['AccessKeyId'],
                    aws_secret_access_key=sts_credentials['SecretAccessKey'],
                    aws_session_token=sts_credentials['SessionToken'],
                    region_name=self.aws_region)
            else:    
                self._session = boto3.session.Session(
                    aws_access_key_id=sts_credentials['AccessKeyId'],
                    aws_secret_access_key=sts_credentials['SecretAccessKey'],
                    aws_session_token=sts_credentials['SessionToken'])


        config = Config(
            retries = {
                'max_attempts': 10,
                'mode': 'standard'
            }
        )

        self._client = self._session.client('ec2', config=config)