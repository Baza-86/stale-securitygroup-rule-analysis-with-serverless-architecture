import json

def lambda_handler(event, context):
    # TODO implement
    #print(event)
    outputFileArray = event['outputFileArray']
    outputCsv = event['outputCsv']
    #print(outputFileArray)
    outputFileArray.append(outputCsv)
    outputRows = event['outputRows']
    
    queryParams = event['queryParams']
    
    queryParams['queryOffset'] += 10
    
    payload_dict = {
        'queryParams': queryParams,
        'outputFileArray': outputFileArray,
        'outputRows': outputRows
    }
    
    return payload_dict